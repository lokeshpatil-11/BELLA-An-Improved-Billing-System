from . import (
    detection,
    recognition,
    tools,
    data_generation,
    pipeline,
    evaluation,
    datasets,
    config,
)

__version__ = "0.0.0"
